import { BusinessDetails, ReviewStats, GalleryItem } from './types';

export const BUSINESS_INFO: BusinessDetails = {
  name: "Noor-e-Azal Foundation Head Office",
  address: "Street No. 39 01, Bhekewal Lahore, 54000",
  phone: "0308 8373075",
  rating: 5.0,
  reviewCount: 43,
  description: "Noor-e-Azal Foundation Pakistan is a non-profit, non-government youth organization working for the betterment of society, serving humanity through initiatives like distributing Iftar meals during Ramadan and other community relief efforts.",
  hours: "Open daily · Closes 12 AM",
  socials: {
    facebook: "https://www.facebook.com/search/top?q=Noor-e-Azal%20Foundation",
    youtube: "https://www.youtube.com/results?search_query=Noor-e-Azal+Foundation",
    tiktok: "https://www.tiktok.com/search?q=Noor-e-Azal%20Foundation"
  }
};

export const REVIEW_STATS: ReviewStats = {
  rating: 5.0,
  count: 43,
  distribution: {
    5: 100, // 100%
    4: 0,
    3: 0,
    2: 0,
    1: 0
  }
};

export const GALLERY_IMAGES: GalleryItem[] = [
  { id: 1, url: "https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&q=80&w=800", alt: "Volunteers distributing food", category: "Distribution" },
  { id: 2, url: "https://images.unsplash.com/photo-1529390003868-6c640a9376c6?auto=format&fit=crop&q=80&w=800", alt: "Community youth gathering", category: "Events" },
  { id: 3, url: "https://images.unsplash.com/photo-1521737711867-e3b97375f902?auto=format&fit=crop&q=80&w=800", alt: "Youth team planning", category: "Team" },
  { id: 4, url: "https://images.unsplash.com/photo-1617450365226-9bf28c5d6668?auto=format&fit=crop&q=80&w=800", alt: "Ramadan Food Drive", category: "Distribution" },
  { id: 5, url: "https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?auto=format&fit=crop&q=80&w=800", alt: "Charity Walk", category: "Events" },
  { id: 6, url: "https://images.unsplash.com/photo-1599059813005-11265ba4b4ce?auto=format&fit=crop&q=80&w=800", alt: "Preparing aid packages", category: "Preparation" },
  { id: 7, url: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&q=80&w=800", alt: "Helping hands", category: "Community" },
  { id: 8, url: "https://images.unsplash.com/photo-1509099836639-18ba1795216d?auto=format&fit=crop&q=80&w=800", alt: "Evening relief work", category: "Distribution" },
];
