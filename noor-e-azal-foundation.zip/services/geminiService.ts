import { GoogleGenAI } from "@google/genai";
import { BUSINESS_INFO } from "../constants";

// Initialize the API client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateAssistantResponse = async (userQuestion: string): Promise<string> => {
  if (!process.env.API_KEY) {
    return "I'm sorry, I cannot connect to the server right now. Please try again later or contact us directly at " + BUSINESS_INFO.phone;
  }

  try {
    const systemPrompt = `
      You are a helpful, compassionate, and energetic virtual assistant for the ${BUSINESS_INFO.name}.
      
      Here is context about the foundation:
      - Name: ${BUSINESS_INFO.name}
      - Location: ${BUSINESS_INFO.address} (Lahore, Pakistan)
      - Mission: ${BUSINESS_INFO.description}
      - Key Activities: Distributing Iftar meals, community relief, youth empowerment.
      - Phone: ${BUSINESS_INFO.phone}
      - Hours: ${BUSINESS_INFO.hours}
      
      Your goal is to answer questions about the foundation, encourage volunteering, and explain how to donate. 
      Keep answers concise (under 100 words), inspiring, and polite. 
      Tone: Hopeful, Youthful, Trustworthy.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userQuestion,
      config: {
        systemInstruction: systemPrompt,
      }
    });

    return response.text || "I apologize, I couldn't generate a response at the moment.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "We are currently experiencing high traffic. Please call us directly at " + BUSINESS_INFO.phone;
  }
};
