import React from 'react';
import { Users, Leaf, HandHeart, CheckCircle } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

const FeatureCard = ({ icon: Icon, title, description, colorClass }: { icon: any, title: string, description: string, colorClass: string }) => (
  <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow duration-300 group">
    <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 transition-colors ${colorClass} group-hover:scale-110 duration-300`}>
      <Icon size={24} />
    </div>
    <h3 className="text-lg font-bold text-slate-900 mb-2">{title}</h3>
    <p className="text-slate-600 text-sm leading-relaxed">{description}</p>
  </div>
);

const About: React.FC = () => {
  return (
    <section id="about" className="scroll-mt-24 py-20 bg-slate-50 relative overflow-hidden">
      {/* Decorative blobs */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-orange-200/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-200/20 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-orange-600 font-semibold tracking-wide uppercase text-sm mb-3">Who We Are</h2>
          <h3 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">
            Driven by Passion, <br/> United for <span className="text-orange-600">Humanity</span>
          </h3>
          <p className="text-lg text-slate-600 leading-relaxed">
             {BUSINESS_INFO.description} We are not just an organization; we are a movement of young hearts beating for the welfare of Pakistan.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <FeatureCard 
            icon={Users}
            title="Youth-Led Initiative"
            description="Our strength lies in our volunteers. We harness the raw energy and innovative ideas of the youth to solve age-old problems."
            colorClass="bg-orange-100 text-orange-600 group-hover:bg-orange-600 group-hover:text-white"
          />
          <FeatureCard 
            icon={Leaf}
            title="Sustainable Impact"
            description="We believe in teaching how to fish rather than just giving a fish. Our projects aim for long-term self-sufficiency."
            colorClass="bg-emerald-100 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white"
          />
          <FeatureCard 
            icon={HandHeart}
            title="Community First"
            description="From emergency flood relief to daily Iftar drives, we are on the ground where we are needed most, when we are needed most."
            colorClass="bg-blue-100 text-blue-600 group-hover:bg-blue-600 group-hover:text-white"
          />
        </div>

        <div className="bg-white rounded-2xl overflow-hidden shadow-xl border border-slate-100">
           <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="p-8 md:p-12 flex flex-col justify-center">
                 <h4 className="text-2xl font-bold text-slate-900 mb-6">Our Core Values</h4>
                 <ul className="space-y-4">
                    {['Transparency in every donation', 'Respect for human dignity', 'Accountability to our donors', 'Inclusivity for all communities'].map((item, idx) => (
                      <li key={idx} className="flex items-center gap-3 text-slate-700">
                         <CheckCircle className="text-emerald-500 shrink-0" size={20} />
                         <span className="font-medium">{item}</span>
                      </li>
                    ))}
                 </ul>
              </div>
              <div className="h-64 lg:h-auto relative">
                 <img 
                   src="https://images.unsplash.com/photo-1593113598332-cd288d649433?q=80&w=1000&auto=format&fit=crop" 
                   alt="Team working" 
                   className="absolute inset-0 w-full h-full object-cover"
                 />
                 <div className="absolute inset-0 bg-gradient-to-l from-transparent to-black/10"></div>
              </div>
           </div>
        </div>

      </div>
    </section>
  );
};

export default About;