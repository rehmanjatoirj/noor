import React from 'react';
import { Phone, MapPin, Mail, Facebook, Youtube, Send } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

const Contact: React.FC = () => {
  const handleSendToPhone = () => {
    const text = `Noor-e-Azal Foundation\n${BUSINESS_INFO.address}\n${BUSINESS_INFO.phone}`;
    if(/Android|iPhone|iPad/i.test(navigator.userAgent)){
         window.location.href = `sms:?body=${encodeURIComponent(text)}`;
    } else {
         alert("Open this on your mobile device to send via SMS, or copy the details: \n\n" + text);
    }
  };

  return (
    <footer id="contact" className="scroll-mt-24 bg-slate-900 text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          
          {/* Brand */}
          <div>
            <h3 className="text-white text-xl font-bold mb-4">Noor-e-Azal Foundation</h3>
            <p className="text-sm text-slate-400 mb-6">
              Working for the betterment of society, serving humanity, and empowering the youth of Pakistan.
            </p>
            <button 
              onClick={handleSendToPhone}
              className="flex items-center gap-2 text-sm text-emerald-400 hover:text-emerald-300 border border-emerald-400/30 px-3 py-1.5 rounded-lg transition-colors"
            >
              <Send size={14} /> Send details to phone
            </button>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-white font-semibold mb-4">Contact Us</h4>
            <div className="space-y-3 text-sm">
              <a href={`tel:${BUSINESS_INFO.phone.replace(/\s/g, '')}`} className="flex items-center gap-3 hover:text-white transition-colors">
                <Phone size={16} className="text-orange-500" />
                {BUSINESS_INFO.phone}
              </a>
              <div className="flex items-start gap-3">
                <MapPin size={16} className="text-orange-500 mt-1" />
                <span>{BUSINESS_INFO.address}</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail size={16} className="text-orange-500" />
                <span>info@nooreazal.org</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Quick Actions</h4>
             <ul className="space-y-2 text-sm">
               <li><button className="hover:text-white text-left" onClick={() => alert('Feature coming soon')}>Suggest an edit</button></li>
               <li><button className="hover:text-white text-left" onClick={() => alert('Feature coming soon')}>Add missing information</button></li>
               <li><button className="hover:text-white text-left" onClick={() => alert('Verification process started')}>Own this business?</button></li>
             </ul>
          </div>

          {/* Map Simulation */}
          <div className="h-48 rounded-xl overflow-hidden bg-slate-800 relative group">
             {/* Map image placeholder */}
             <img 
              src="https://images.unsplash.com/photo-1569336415962-a4bd9f69cd83?q=80&w=1000&auto=format&fit=crop" 
              alt="Map Location" 
              className="w-full h-full object-cover opacity-50 group-hover:opacity-60 transition-opacity" 
             />
             <div className="absolute inset-0 flex items-center justify-center">
                <a 
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(BUSINESS_INFO.address)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="bg-white/10 backdrop-blur-md border border-white/20 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-white/20 transition-colors flex items-center gap-2"
                >
                  <MapPin size={16} /> View on Map
                </a>
             </div>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-slate-500">© {new Date().getFullYear()} Noor-e-Azal Foundation. All rights reserved.</p>
          <div className="flex space-x-6">
             {/* Social Icons linked to search queries */}
             <a href={BUSINESS_INFO.socials.facebook} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-white transition-colors" aria-label="Facebook"><Facebook size={20} /></a>
             <a href={BUSINESS_INFO.socials.youtube} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-white transition-colors" aria-label="YouTube"><Youtube size={20} /></a>
             <a href={BUSINESS_INFO.socials.tiktok} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-white transition-colors" aria-label="TikTok">
               <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5"/></svg>
             </a>
          </div>
        </div>

      </div>
    </footer>
  );
};

export default Contact;