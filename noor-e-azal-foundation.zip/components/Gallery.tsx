import React, { useState } from 'react';
import { Camera, ArrowRight, ExternalLink } from 'lucide-react';
import { GALLERY_IMAGES } from '../constants';

const Gallery: React.FC = () => {
  const [visibleCount, setVisibleCount] = useState(6);

  const showMore = () => {
    setVisibleCount(prev => Math.min(prev + 3, GALLERY_IMAGES.length));
  };

  return (
    <section id="gallery" className="scroll-mt-24 py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-10 gap-4">
          <div>
            <h2 className="text-orange-600 font-semibold tracking-wide uppercase text-sm mb-2">Our Gallery</h2>
            <h3 className="text-3xl font-bold text-slate-900">Moments of Impact</h3>
            <p className="text-slate-500 mt-2 max-w-lg">Witness the joy and relief we bring to communities through our various initiatives.</p>
          </div>
          <button className="hidden md:flex items-center text-slate-900 font-semibold hover:text-orange-600 transition-colors group">
            View all albums <ArrowRight size={20} className="ml-2 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {GALLERY_IMAGES.slice(0, visibleCount).map((img) => (
            <div key={img.id} className="group relative aspect-[4/3] overflow-hidden rounded-2xl bg-slate-100 cursor-pointer shadow-sm hover:shadow-xl transition-all duration-500">
              <img 
                src={img.url} 
                alt={img.alt} 
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                 <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-75">
                    <span className="inline-block px-2 py-1 bg-orange-500 text-white text-xs font-bold rounded mb-2">{img.category}</span>
                    <p className="text-white font-medium text-lg leading-tight">{img.alt}</p>
                 </div>
              </div>
            </div>
          ))}
        </div>

        {visibleCount < GALLERY_IMAGES.length && (
          <div className="mt-12 text-center">
            <button 
              onClick={showMore}
              className="bg-white border-2 border-slate-200 text-slate-700 px-8 py-3 rounded-full font-bold hover:bg-slate-50 hover:border-slate-300 transition-all shadow-sm active:scale-95"
            >
              Load More Moments
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default Gallery;