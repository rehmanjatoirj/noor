import React from 'react';
import { MapPin, Share2, Star, Clock, HeartHandshake, PhoneCall, ArrowRight, CheckCircle2 } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

const Hero: React.FC = () => {
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: BUSINESS_INFO.name,
          text: BUSINESS_INFO.description,
          url: window.location.href,
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      try {
        await navigator.clipboard.writeText(window.location.href);
        alert('Link copied to clipboard!');
      } catch (err) {
        alert('Could not copy link.');
      }
    }
  };

  const handleExternalLink = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const ActionButton = ({ icon: Icon, label, onClick, highlight = false }: { icon: any, label: string, onClick?: () => void, highlight?: boolean }) => (
    <button
      onClick={onClick}
      className={`flex flex-col items-center justify-center gap-2 px-6 py-4 rounded-xl transition-all duration-300 transform hover:-translate-y-1 ${
        highlight 
          ? 'bg-orange-600 text-white shadow-lg shadow-orange-600/30 hover:bg-orange-700' 
          : 'bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20'
      }`}
    >
      <Icon size={24} className={highlight ? 'text-white' : 'text-orange-400'} />
      <span className="text-sm font-semibold tracking-wide">{label}</span>
    </button>
  );

  return (
    <div className="relative min-h-[85vh] flex flex-col justify-center overflow-hidden">
      {/* Immersive Background */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=2070&auto=format&fit=crop" 
          alt="Foundation Background" 
          className="w-full h-full object-cover"
        />
        {/* Modern Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 via-slate-900/70 to-slate-900/30"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-20 pb-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          {/* Text Content */}
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-500/20 border border-orange-500/30 text-orange-300 text-sm font-medium">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500"></span>
              </span>
              Serving Humanity Since 2018
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight">
              Empowering Youth, <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-amber-200">
                Transforming Lives.
              </span>
            </h1>
            
            <p className="text-lg text-slate-300 max-w-xl leading-relaxed">
              {BUSINESS_INFO.description}
            </p>

            <div className="flex flex-wrap gap-4 pt-2 text-sm text-slate-300">
               <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-lg border border-white/10">
                 <MapPin className="text-orange-400" size={18} />
                 <span>Lahore, Pakistan</span>
               </div>
               <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-lg border border-white/10">
                 <Clock className="text-emerald-400" size={18} />
                 <span>{BUSINESS_INFO.hours}</span>
               </div>
               <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-lg border border-white/10">
                 <Star className="text-yellow-400 fill-yellow-400" size={18} />
                 <span className="font-bold text-white">{BUSINESS_INFO.rating}</span>
                 <span>({BUSINESS_INFO.reviewCount} Reviews)</span>
               </div>
            </div>
          </div>

          {/* Action Dock (Desktop Right / Mobile Bottom) */}
          <div className="flex flex-col gap-4">
             {/* Main CTA Card */}
             <div className="bg-white/10 backdrop-blur-xl border border-white/20 p-6 rounded-2xl shadow-2xl transform lg:rotate-1 hover:rotate-0 transition-transform duration-500">
                <div className="flex items-center justify-between mb-6">
                   <div className="flex items-center gap-3">
                      <img src="https://ui-avatars.com/api/?name=Noor+e+Azal&background=f97316&color=fff&size=128&font-size=0.33" alt="Logo" className="w-12 h-12 rounded-full border-2 border-white/30" />
                      <div>
                        <h3 className="text-white font-bold text-lg">{BUSINESS_INFO.name}</h3>
                        <p className="text-slate-300 text-xs">Official Head Office</p>
                      </div>
                   </div>
                   <div className="bg-emerald-500/20 text-emerald-300 px-2 py-1 rounded text-xs font-bold border border-emerald-500/30">
                      OPEN NOW
                   </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <ActionButton 
                      icon={PhoneCall} 
                      label="Call Now" 
                      onClick={() => window.location.href = `tel:${BUSINESS_INFO.phone}`}
                      highlight
                  />
                  <ActionButton 
                      icon={HeartHandshake} 
                      label="Donate" 
                      onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                  />
                  <ActionButton 
                      icon={MapPin} 
                      label="Directions" 
                      onClick={() => handleExternalLink(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(BUSINESS_INFO.address)}`)} 
                  />
                  <ActionButton 
                      icon={Share2} 
                      label="Share" 
                      onClick={handleShare}
                  />
                </div>
                
                <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
                   <div className="flex -space-x-2">
                      {[1,2,3].map(i => (
                        <img key={i} src={`https://i.pravatar.cc/100?img=${i+10}`} className="w-6 h-6 rounded-full border border-slate-900" alt="Supporter" />
                      ))}
                      <div className="w-6 h-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-[10px]">+40</div>
                   </div>
                   <span>Joined by 40+ volunteers this month</span>
                </div>
             </div>
          </div>

        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-white/50 animate-bounce hidden md:block">
        <ArrowRight className="rotate-90" size={24} />
      </div>
    </div>
  );
};

export default Hero;
