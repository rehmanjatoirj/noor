import React, { useState, useEffect } from 'react';
import { Menu, X, Heart } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = () => {
    setIsOpen(false);
  };

  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'About', href: '#about' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'Contact', href: '#contact' },
  ];

  // The header should be in "light mode" (white background, dark text) if scrolled OR if the mobile menu is open
  const isLightMode = scrolled || isOpen;

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isLightMode 
        ? 'bg-white/95 backdrop-blur-md shadow-md py-2' 
        : 'bg-gradient-to-b from-black/60 to-transparent py-4'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          
          {/* Logo */}
          <div 
            className="flex-shrink-0 flex items-center gap-2 cursor-pointer group" 
            onClick={() => { window.scrollTo(0,0); handleNavClick(); }}
          >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-lg transition-colors duration-300 ${isLightMode ? 'bg-orange-600' : 'bg-orange-500 group-hover:bg-orange-600'}`}>
              <Heart size={20} fill="currentColor" />
            </div>
            <span className={`font-bold text-xl tracking-tight transition-colors duration-300 ${isLightMode ? 'text-slate-900' : 'text-white drop-shadow-md'}`}>
              Noor-e-Azal
            </span>
          </div>
          
          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className={`text-sm font-medium transition-colors duration-300 hover:text-orange-500 ${
                  isLightMode ? 'text-slate-600' : 'text-slate-100 hover:text-white drop-shadow-sm'
                }`}
              >
                {link.name}
              </a>
            ))}
            <a
              href={`tel:${BUSINESS_INFO.phone.replace(/\s/g, '')}`}
              className="bg-emerald-600 text-white px-6 py-2.5 rounded-full text-sm font-bold hover:bg-emerald-700 transition-all hover:shadow-lg hover:shadow-emerald-600/30 transform hover:-translate-y-0.5"
            >
              Donate Now
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className={`focus:outline-none p-2 rounded-lg transition-colors duration-300 ${
                isLightMode ? 'text-slate-900 hover:bg-slate-100' : 'text-white hover:bg-white/10 drop-shadow-md'
              }`}
              aria-label="Toggle menu"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`md:hidden absolute top-full left-0 right-0 bg-white border-b border-gray-100 shadow-xl transition-all duration-300 origin-top overflow-hidden ${
        isOpen ? 'opacity-100 scale-y-100 max-h-screen' : 'opacity-0 scale-y-0 max-h-0'
      }`}>
        <div className="px-4 py-6 space-y-3 bg-white">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={handleNavClick}
              className="text-slate-600 hover:text-orange-600 hover:bg-orange-50 block px-4 py-3 rounded-lg text-base font-medium transition-colors border border-transparent hover:border-orange-100"
            >
              {link.name}
            </a>
          ))}
          <a
              href={`tel:${BUSINESS_INFO.phone.replace(/\s/g, '')}`}
              onClick={handleNavClick}
              className="block w-full text-center mt-6 bg-emerald-600 text-white px-5 py-4 rounded-xl font-bold shadow-md active:scale-95 transition-transform"
          >
            Donate Now
          </a>
        </div>
        {/* Backdrop for clicking outside */}
        {isOpen && (
          <div className="fixed inset-0 top-[60px] z-[-1] bg-black/20 backdrop-blur-sm md:hidden" onClick={() => setIsOpen(false)}></div>
        )}
      </div>
    </nav>
  );
};

export default Header;
