import React from 'react';
import { Star, ThumbsUp, MessageSquareQuote } from 'lucide-react';
import { REVIEW_STATS } from '../constants';

const Reviews: React.FC = () => {
  return (
    <section id="reviews" className="scroll-mt-24 py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
           <h2 className="text-3xl font-bold text-slate-900">Voices of Trust</h2>
           <p className="text-slate-500 mt-2">What our community and volunteers say about us</p>
        </div>
        
        <div className="bg-white p-8 md:p-10 rounded-3xl shadow-xl border border-slate-100 grid grid-cols-1 lg:grid-cols-3 gap-10 lg:gap-16">
          
          {/* Overall Rating */}
          <div className="flex flex-col justify-center items-center lg:items-start text-center lg:text-left border-b lg:border-b-0 lg:border-r border-slate-100 pb-8 lg:pb-0 lg:pr-8">
            <div className="text-6xl font-black text-slate-900 mb-2">{REVIEW_STATS.rating}</div>
            <div className="flex gap-1 text-orange-400 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={24} fill="currentColor" />
              ))}
            </div>
            <p className="text-slate-500 font-medium">Based on {REVIEW_STATS.count} genuine reviews</p>
            <button className="mt-6 text-emerald-600 font-bold hover:text-emerald-700 underline underline-offset-4">
              Write a Review
            </button>
          </div>

          {/* Bar Graph */}
          <div className="flex flex-col justify-center space-y-3 w-full">
            {[5, 4, 3, 2, 1].map((star) => (
              <div key={star} className="flex items-center gap-4">
                <span className="text-sm font-bold text-slate-600 w-3">{star}</span>
                <Star size={14} className="text-slate-300" fill="currentColor" />
                <div className="flex-1 h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-orange-500 rounded-full transition-all duration-1000 ease-out"
                    style={{ width: `${REVIEW_STATS.distribution[star as keyof typeof REVIEW_STATS.distribution]}%` }}
                  ></div>
                </div>
                <span className="text-xs text-slate-400 w-8 text-right">
                  {REVIEW_STATS.distribution[star as keyof typeof REVIEW_STATS.distribution]}%
                </span>
              </div>
            ))}
          </div>

          {/* Highlighted Review Card */}
          <div className="relative bg-slate-50 p-6 rounded-2xl border border-slate-100">
            <MessageSquareQuote className="absolute top-4 right-4 text-orange-200" size={40} />
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white text-sm font-bold shadow-md">
                SA
              </div>
              <div>
                <span className="block text-sm font-bold text-slate-900">Sample Reviewer</span>
                <span className="block text-xs text-slate-400">Review from Google</span>
              </div>
            </div>
            <div className="flex gap-1 text-orange-400 text-xs mb-3">
               {[...Array(5)].map((_, i) => <Star key={i} size={14} fill="currentColor" />)}
            </div>
            <p className="text-slate-700 text-sm italic mb-6 leading-relaxed">
              "Platform, serving humanity 👍 All the best in this good initiative. Highly recommended for those who want to volunteer."
            </p>
            <div className="flex items-center justify-between pt-4 border-t border-slate-200/50">
               <span className="text-xs text-slate-400">Posted 2 months ago</span>
               <button className="flex items-center gap-1.5 text-slate-500 hover:text-slate-800 text-xs font-medium transition-colors">
                <ThumbsUp size={14} /> Helpful
               </button>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Reviews;