export interface BusinessDetails {
  name: string;
  address: string;
  phone: string;
  rating: number;
  reviewCount: number;
  description: string;
  hours: string;
  socials: {
    facebook: string;
    youtube: string;
    tiktok: string;
  };
}

export interface ReviewStats {
  rating: number;
  count: number;
  distribution: {
    5: number;
    4: number;
    3: number;
    2: number;
    1: number;
  };
}

export interface NavItem {
  label: string;
  id: string;
}

export interface GalleryItem {
  id: number;
  url: string;
  alt: string;
  category: string;
}
