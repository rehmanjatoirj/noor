import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Reviews from './components/Reviews';
import Gallery from './components/Gallery';
import Contact from './components/Contact';
import Assistant from './components/Assistant';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      <main>
        <Hero />
        <About />
        <Gallery />
        <Reviews />
      </main>
      <Contact />
      <Assistant />
    </div>
  );
};

export default App;
